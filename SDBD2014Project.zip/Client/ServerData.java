public class ServerData{
	public String ip;
	public int port;

	public ServerData(String ip, int port){
		this.ip = ip;
		this.port = port;
	}
}