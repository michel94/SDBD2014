import java.io.*;
import java.util.ArrayList;

public class InviteUsers extends ArrayList<InviteUser>{
	private static final long serialVersionUID = 1L;
	public int flag;
	public InviteUsers(){
		super();
	}
}
