import java.io.*;
import java.util.ArrayList;

public class RemoveUsersFromGroup extends ArrayList<RemoveUserFromGroup>{
	private static final long serialVersionUID = 1L;
	
	public RemoveUsersFromGroup(){
		super();
	}
}
