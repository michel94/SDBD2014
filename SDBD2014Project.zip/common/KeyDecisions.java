import java.io.Serializable;
import java.util.ArrayList;

public class KeyDecisions extends ArrayList<KeyDecision> implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public KeyDecisions(){
		
	}
}