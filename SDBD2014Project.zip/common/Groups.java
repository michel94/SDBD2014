import java.io.Serializable;
import java.util.ArrayList;

public class Groups extends ArrayList<Group> implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public Groups(){
		
	}
}
