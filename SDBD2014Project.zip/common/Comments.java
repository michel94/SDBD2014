import java.io.Serializable;
import java.util.ArrayList;

public class Comments extends ArrayList<Comment> implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public Comments(){
		
	}
}