import java.io.*;

public class Confirmation implements Serializable{
	int error;
	public Confirmation(){
		
	}
}